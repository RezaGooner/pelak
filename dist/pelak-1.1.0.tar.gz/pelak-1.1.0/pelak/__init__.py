from .generate import generate_plate
from .generate import generate_plates
from .generate import random_generate_plate


from .location import location

__version__ = '1.1.0'
